# VOID X — budowanie APK przez GitHub Actions (telefon Android)

Ten pakiet pozwala zbudować **debug APK** w chmurze GitHub Actions. Nie wymaga instalowania Android Studio ani Android SDK na telefonie.

## Pliki
- `VOID_X_Android_Studio_v1.3.0_source.zip` — źródła launchera.
- `.github/workflows/build-apk.yml` — przepis GitHub Actions do kompilacji.
- Ten plik — instrukcja konfiguracji.

## Krok 1. Utwórz repozytorium GitHub
1. Otwórz https://github.com w przeglądarce telefonu i zaloguj się.
2. Utwórz nowe repozytorium, np. `VOID-X-Launcher`.
3. Na początek wybierz **Private** (prywatne). Nie dodawaj README ani licencji, jeśli GitHub pyta o inicjalizację.
4. Utwórz repozytorium.

## Krok 2. Wgraj ZIP ze źródłami
1. Otwórz repozytorium.
2. Wybierz **Add file → Upload files**.
3. Wgraj plik `VOID_X_Android_Studio_v1.3.0_source.zip` z tego pakietu.
4. Zatwierdź przez **Commit changes**.

## Krok 3. Dodaj workflow
1. W repozytorium wybierz **Add file → Create new file**.
2. W polu nazwy pliku wpisz dokładnie:
   `.github/workflows/build-apk.yml`
3. Otwórz plik `build-apk.yml` z tego pakietu i skopiuj całą jego zawartość.
4. Wklej treść do edytora GitHub.
5. Zapisz przez **Commit changes**.

Dodanie workflow powinno uruchomić kompilację automatycznie. Możesz też wejść w zakładkę **Actions**, wybrać **Build VOID X APK** i nacisnąć **Run workflow**.

## Krok 4. Pobierz APK na telefon
1. Wejdź w zakładkę **Actions** w repozytorium.
2. Otwórz najnowsze uruchomienie „Build VOID X APK”.
3. Poczekaj, aż wszystkie kroki zakończą się zielonym znakiem sukcesu.
4. Na dole strony znajdź **Artifacts**.
5. Pobierz `VOID-X-1.3.0-debug-APK`.
6. GitHub pobierze ZIP z plikiem `app-debug.apk` w środku.
7. Rozpakuj pobrany ZIP na telefonie i wybierz `app-debug.apk`, aby rozpocząć instalację. Android może poprosić o zezwolenie przeglądarce lub menedżerowi plików na instalowanie aplikacji z tego źródła.

## Ważne informacje
- To będzie **debug APK**, podpisany testowym kluczem debugowym tworzonym przez Android Gradle Plugin. Nadaje się do instalacji i testów, ale nie jest finalnym, podpisanym kluczem wydawniczym.
- Nie udostępniaj haseł, tokenów ani kluczy podpisujących w repozytorium lub czacie.
- Jeśli kompilacja zakończy się błędem, otwórz nieudane uruchomienie w Actions, rozwiń krok **Build debug APK**, skopiuj końcowy komunikat błędu (lub pobierz log) i prześlij go tutaj. Na podstawie logu poprawię projekt.
- Zielony wynik kompilacji potwierdza zbudowanie APK, ale nie gwarantuje jeszcze poprawnego działania na POCO X6 Pro. Po instalacji trzeba sprawdzić ustawienie launchera HOME, widgety, dostęp do powiadomień i sterowanie multimediami.
- APK może nie być kompatybilny z istniejącą instalacją o innym podpisie. W takim przypadku usuń starą testową wersję VOID X przed instalacją nowej (może to skasować jej ustawienia).

## Prywatność i bezpieczeństwo
Repozytorium prywatne jest dobrym wyborem dla projektu w trakcie prac. Workflow potrzebuje tylko odczytu zawartości repozytorium i zapisuje APK jako artefakt kompilacji. Nie wymaga żadnych sekretów GitHub.
