plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.voidx.launcher"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.voidx.launcher"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "1.3.0"
    }
}
