package com.voidx.launcher

import android.app.Activity
import android.app.Dialog
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.widget.SeekBar
import kotlin.math.abs

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var appGrid: GridLayout
    private lateinit var search: EditText
    private val prefs by lazy { getSharedPreferences("void_x_preferences", MODE_PRIVATE) }
    private var accent = Color.rgb(91, 205, 117)
    private var showLabels = true
    private var columns = 4
    private var showHiddenApps = false
    private val hiddenPackages: MutableSet<String> by lazy {
        (prefs.getStringSet("hidden_packages", emptySet()) ?: emptySet()).toMutableSet()
    }
    private var islandExpanded = false
    private var islandPanel: LinearLayout? = null
    private var dock: LinearLayout? = null
    private var activeController: MediaController? = null
    private val mediaCallback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) { runOnUiThread { if (islandExpanded) renderIslandPanel() } }
        override fun onPlaybackStateChanged(state: android.media.session.PlaybackState?) { runOnUiThread { if (islandExpanded) renderIslandPanel() } }
        override fun onSessionDestroyed() { runOnUiThread { refreshMedia() } }
    }
    private lateinit var widgetHost: AppWidgetHost
    private lateinit var widgetManager: AppWidgetManager
    private lateinit var widgetContainer: LinearLayout
    private val widgetHostId = 0x564f
    private val requestPickWidget = 701
    private var allApps: List<android.content.pm.ResolveInfo> = emptyList()
    private var downY = 0f
    private var downX = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        accent = prefs.getInt("accent", 0xff55c878.toInt())
        showLabels = prefs.getBoolean("show_labels", true)
        columns = prefs.getInt("columns", 4).coerceIn(2, 6)
        showHiddenApps = prefs.getBoolean("show_hidden_apps", false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        widgetManager = AppWidgetManager.getInstance(this)
        widgetHost = AppWidgetHost(this, widgetHostId)
        try { widgetHost.startListening() } catch (_: Exception) { }
        buildHome()
        restoreWidgets()
        loadApps()
    }

    override fun onResume() {
        super.onResume()
        loadApps()
        refreshMedia()
    }

    override fun onDestroy() {
        try { activeController?.unregisterCallback(mediaCallback) } catch (_: Exception) { }
        try { widgetHost.stopListening() } catch (_: Exception) { }
        super.onDestroy()
    }

    @Deprecated("Android widget picker result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != requestPickWidget) return
        val appWidgetId = data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1) ?: -1
        if (resultCode == Activity.RESULT_OK && appWidgetId != -1) {
            attachWidget(appWidgetId)
        } else if (appWidgetId != -1) {
            widgetHost.deleteAppWidgetId(appWidgetId)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun glass(color: Int = 0x995e6868.toInt(), radius: Float = 26f) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius.toInt()).toFloat()
        setStroke(dp(1), 0x33ffffff)
    }
    private fun text(value: String, size: Float, color: Int = Color.WHITE) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); gravity = Gravity.CENTER_VERTICAL
    }
    private fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)

    private fun buildHome() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(48), dp(20), dp(14))
            background = try { WallpaperManager.getInstance(this@MainActivity).drawable }
            catch (_: Exception) { GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xff071b24.toInt(), 0xff153c30.toInt(), 0xff07121c.toInt())) }
        }
        setContentView(root)
        root.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downY = event.y; downX = event.x; true }
                MotionEvent.ACTION_UP -> {
                    val dy = event.y - downY; val dx = event.x - downX
                    if (abs(dy) > dp(70) && abs(dy) > abs(dx)) {
                        if (dy > 0) showControlCenter() else { search.requestFocus(); search.post { (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).showSoftInput(search, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT) } }
                        true
                    } else false
                }
                else -> false
            }
        }

        val islandRow = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(14)) }
        val island = LinearLayout(this).apply {
            gravity = Gravity.CENTER; setPadding(dp(22), dp(8), dp(22), dp(8)); background = glass(Color.BLACK, 40f)
            isClickable = true; isFocusable = true; setOnClickListener { toggleIsland() }
        }
        island.addView(text("●  VOID X", 12f)); islandRow.addView(island, lp(-2, dp(38)))
        root.addView(islandRow, lp(-1, dp(50)))

        val weather = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(14), dp(18), dp(14)); background = glass(0x997d8c91.toInt(), 32f)
        }
        weather.addView(text("VOID WEATHER  ·  LIVE DATA NOT CONNECTED", 11f, 0xffdce9e4.toInt()))
        weather.addView(text("Pogoda", 29f))
        weather.addView(text("Podłącz dostawcę pogody, aby wyświetlać aktualne warunki.", 12f, 0xffe0e0e0.toInt()))
        root.addView(weather, lp(-1, dp(130)))

        widgetContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(6), 0, dp(4)) }
        val widgetHeader = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        widgetHeader.addView(text("WIDGETY", 10f, 0xffdce9e4.toInt()), LinearLayout.LayoutParams(0, dp(36), 1f))
        widgetHeader.addView(actionButton("+ DODAJ", 0xff355d4b.toInt()) { pickWidget() }, lp(dp(104), dp(34)))
        widgetContainer.addView(widgetHeader)
        root.addView(widgetContainer, lp(-1, -2))

        root.addView(View(this), LinearLayout.LayoutParams(1, 0, .35f))
        search = EditText(this).apply {
            hint = "Szukaj aplikacji"; textSize = 16f; setTextColor(Color.WHITE); setHintTextColor(0xffdddddd.toInt())
            setSingleLine(true); setPadding(dp(18), dp(4), dp(18), dp(4)); background = glass(0xbb252525.toInt(), 18f)
        }
        root.addView(search, lp(-1, dp(52)))
        val scroll = ScrollView(this).apply { isFillViewport = true }
        appGrid = GridLayout(this).apply { columnCount = columns; alignmentMode = GridLayout.ALIGN_BOUNDS; useDefaultMargins = false }
        scroll.addView(appGrid, ViewGroup.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1.25f))

        val utilityRow = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        utilityRow.addView(actionButton("CENTRUM", 0x99388b48.toInt()) { showControlCenter() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        utilityRow.addView(actionButton("USTAWIENIA", 0x99304448.toInt()) { showSettings() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        root.addView(utilityRow, lp(-1, dp(48)))

        dock = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL; setPadding(dp(8), dp(8), dp(8), dp(8)); background = glass(withAlpha(accent, 0xaa), 34f) }
        root.addView(dock, lp(-1, dp(76)))
        buildDock()
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderApps(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun actionButton(title: String, color: Int, action: () -> Unit) = Button(this).apply {
        text = title; textSize = 11f; setTextColor(Color.WHITE); background = glass(color, 20f); setOnClickListener { action() }
    }

    private fun pickWidget() {
        val appWidgetId = widgetHost.allocateAppWidgetId()
        val pick = Intent(AppWidgetManager.ACTION_APPWIDGET_PICK).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
        try { startActivityForResult(pick, requestPickWidget) }
        catch (_: Exception) { widgetHost.deleteAppWidgetId(appWidgetId); Toast.makeText(this, "Nie można otworzyć wyboru widgetów", Toast.LENGTH_SHORT).show() }
    }

    private fun attachWidget(appWidgetId: Int) {
        val info = widgetManager.getAppWidgetInfo(appWidgetId)
        if (info == null) { widgetHost.deleteAppWidgetId(appWidgetId); return }
        val hostView = widgetHost.createView(this, appWidgetId, info)
        hostView.setAppWidget(appWidgetId, info)
        hostView.setPadding(dp(4), dp(4), dp(4), dp(4))
        hostView.setOnLongClickListener {
            android.app.AlertDialog.Builder(this)
                .setTitle("Usuń widget?")
                .setMessage("Widget zostanie usunięty z ekranu VOID X.")
                .setNegativeButton("Anuluj", null)
                .setPositiveButton("Usuń") { _, _ -> removeWidget(appWidgetId, hostView) }
                .show()
            true
        }
        widgetContainer.addView(hostView, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        val ids = prefs.getStringSet("widget_ids", emptySet())?.toMutableSet() ?: mutableSetOf()
        ids.add(appWidgetId.toString())
        prefs.edit().putStringSet("widget_ids", ids).apply()
    }

    private fun removeWidget(appWidgetId: Int, view: View) {
        widgetContainer.removeView(view)
        widgetHost.deleteAppWidgetId(appWidgetId)
        val ids = prefs.getStringSet("widget_ids", emptySet())?.toMutableSet() ?: mutableSetOf()
        ids.remove(appWidgetId.toString())
        prefs.edit().putStringSet("widget_ids", ids).apply()
    }

    private fun restoreWidgets() {
        val ids = prefs.getStringSet("widget_ids", emptySet()) ?: emptySet()
        ids.forEach { raw -> raw.toIntOrNull()?.let { id ->
            val info = widgetManager.getAppWidgetInfo(id)
            if (info != null) {
                val hostView = widgetHost.createView(this, id, info)
                hostView.setAppWidget(id, info)
                hostView.setOnLongClickListener {
                    android.app.AlertDialog.Builder(this)
                        .setTitle("Usuń widget?")
                        .setMessage("Widget zostanie usunięty z ekranu VOID X.")
                        .setNegativeButton("Anuluj", null)
                        .setPositiveButton("Usuń") { _, _ -> removeWidget(id, hostView) }
                        .show()
                    true
                }
                widgetContainer.addView(hostView, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
            }
        } }
    }

    private fun loadApps() {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        allApps = packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .distinctBy { it.activityInfo.packageName }.sortedBy { it.loadLabel(packageManager).toString().lowercase() }
        renderApps("")
    }

    private fun renderApps(filter: String) {
        if (!::appGrid.isInitialized) return
        appGrid.removeAllViews()
        allApps.filter { info ->
            val packageName = info.activityInfo.packageName
            (showHiddenApps || packageName !in hiddenPackages) &&
                info.loadLabel(packageManager).toString().contains(filter, true)
        }.forEach { info ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(3), dp(8), dp(3), dp(8))
                isClickable = true; isFocusable = true
                setOnClickListener { packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)?.let { startActivity(it) } }
                setOnLongClickListener { showAppActions(info.activityInfo.packageName, info.loadLabel(packageManager).toString()); true }
            }
            item.addView(ImageView(this).apply { setImageDrawable(info.loadIcon(packageManager)); scaleType = ImageView.ScaleType.FIT_CENTER }, lp(dp(46), dp(46)))
            if (showLabels) item.addView(text(info.loadLabel(packageManager).toString(), 10.5f).apply { gravity = Gravity.CENTER; maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END })
            val p = GridLayout.LayoutParams().apply { width = 0; height = dp(if (showLabels) 78 else 62); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f) }
            appGrid.addView(item, p)
        }
    }

    private fun buildDock() {
        val target = dock ?: return
        target.removeAllViews()
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_BROWSER),
            Intent(Settings.ACTION_SETTINGS)
        )
        intents.forEachIndexed { index, intent ->
            val resolved = packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
            val tile = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.VERTICAL; background = glass(0x99ffffff.toInt(), 22f); isClickable = true }
            if (resolved != null) {
                val icon = resolved.loadIcon(packageManager)
                tile.addView(ImageView(this).apply { setImageDrawable(icon) }, lp(dp(34), dp(34)))
                tile.setOnClickListener {
                    try { startActivity(intent) }
                    catch (_: Exception) {
                        Toast.makeText(this@MainActivity, "Brak dostępnej aplikacji dla tego skrótu", Toast.LENGTH_SHORT).show()
                    }
                }
            } else {
                tile.addView(text(listOf("☎", "◉", "◎", "⚙")[index], 23f))
                tile.setOnClickListener { startActivity(Intent(Settings.ACTION_SETTINGS)) }
            }
            val p = LinearLayout.LayoutParams(0, dp(52), 1f); p.setMargins(dp(5), 0, dp(5), 0); target.addView(tile, p)
        }
    }

    private fun refreshMedia() {
        val previous = activeController
        try {
            val manager = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val component = ComponentName(this, MediaNotificationListener::class.java)
            val sessions = manager.getActiveSessions(component)
            activeController = sessions.firstOrNull { it.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING }
                ?: sessions.firstOrNull()
        } catch (_: SecurityException) { activeController = null }
        if (previous?.sessionToken != activeController?.sessionToken) {
            try { previous?.unregisterCallback(mediaCallback) } catch (_: Exception) { }
            try { activeController?.registerCallback(mediaCallback) } catch (_: Exception) { }
        }
        if (islandExpanded) renderIslandPanel()
    }

    private fun toggleIsland() {
        if (islandExpanded) {
            islandPanel?.let { root.removeView(it) }; islandPanel = null; islandExpanded = false
        } else {
            islandExpanded = true; renderIslandPanel()
        }
    }

    private fun renderIslandPanel() {
        islandPanel?.let { root.removeView(it) }
        val panelView = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(14), dp(18), dp(14)); background = glass(0xee090d10.toInt(), 28f) }
        panelView.addView(text("VOID ISLAND  ·  MEDIA", 11f, accent))
        val controller = activeController
        val metadata = controller?.metadata
        val title = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Brak aktywnego odtwarzania"
        val artist = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "Włącz dostęp do powiadomień, aby połączyć media"
        val info = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, dp(4)) }
        val art = metadata?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_ART)
        if (art != null) info.addView(ImageView(this).apply { setImageBitmap(art); scaleType = ImageView.ScaleType.CENTER_CROP }, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(12) })
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(text(title, 15f)); addView(text(artist, 12f, 0xffc7d0ce.toInt())) }
        info.addView(labels, LinearLayout.LayoutParams(0, -2, 1f)); panelView.addView(info)
        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        listOf("|◀", if (controller?.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING) "Ⅱ" else "▶", "▶|").forEachIndexed { i, symbol ->
            val b = actionButton(symbol, 0xff293438.toInt()) {
                val c = activeController ?: return@actionButton
                try { when (i) { 0 -> c.transportControls.skipToPrevious(); 1 -> if (c.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING) c.transportControls.pause() else c.transportControls.play(); 2 -> c.transportControls.skipToNext() } } catch (_: Exception) { }
                refreshMedia()
            }
            controls.addView(b, LinearLayout.LayoutParams(0, dp(42), 1f).apply { setMargins(dp(4), dp(8), dp(4), 0) })
        }
        panelView.addView(controls)
        if (controller == null) {
            val access = actionButton("WŁĄCZ DOSTĘP DO POWIADOMIEŃ", 0xff355d4b.toInt()) { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
            panelView.addView(access, lp(-1, dp(42)))
        }
        val close = text("Dotknij, aby zwinąć", 10f, 0xffaaaaaa.toInt()).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0); setOnClickListener { toggleIsland() } }
        panelView.addView(close)
        panelView.setOnClickListener { /* controls handle their own actions */ }
        root.addView(panelView, 1.coerceAtMost(root.childCount), lp(-1, -2)); islandPanel = panelView
    }

    private fun showControlCenter() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(18)); background = glass(0xf0182024.toInt(), 28f) }
        box.addView(text("VOID CONTROL CENTER", 18f))
        box.addView(text("Szybkie skróty systemowe", 12f, 0xffb8c5c0.toInt()))
        val brightness = SeekBar(this).apply { max = 255; progress = try { Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) } catch (_: Exception) { 128 } }
        box.addView(text("Jasność ekranu", 13f)); box.addView(brightness)
        brightness.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, value: Int, fromUser: Boolean) { if (fromUser && Settings.System.canWrite(this@MainActivity)) Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, value) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { if (!Settings.System.canWrite(this@MainActivity)) startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, android.net.Uri.parse("package:$packageName"))) }
        })
        val rows = listOf("Wi-Fi" to Settings.ACTION_WIFI_SETTINGS, "Bluetooth" to Settings.ACTION_BLUETOOTH_SETTINGS, "Sieć i internet" to Settings.ACTION_WIRELESS_SETTINGS, "Ustawienia systemu" to Settings.ACTION_SETTINGS, "Bateria" to Settings.ACTION_BATTERY_SAVER_SETTINGS)
        rows.forEach { (name, action) -> box.addView(actionButton(name, 0xff293b3b.toInt()) { try { startActivity(Intent(action)) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) } }, lp(-1, dp(44))) }
        showDialog(box, .9f)
    }

    private fun showSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(20), dp(22), dp(20)); background = glass(0xff172126.toInt(), 26f) }
        box.addView(text("VOID X  /  PERSONALIZACJA", 18f))
        box.addView(text("Kolor akcentu", 13f))
        val colors = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(0xff55c878.toInt(), 0xff55aaff.toInt(), 0xffb17aff.toInt(), 0xffff6262.toInt(), 0xffffffff.toInt()).forEach { color ->
            val swatch = Button(this).apply { text = "●"; setTextColor(color); textSize = 22f; setOnClickListener { accent = color; prefs.edit().putInt("accent", color).apply(); dock?.background = glass(withAlpha(accent, 0xaa), 34f) } }
            colors.addView(swatch, LinearLayout.LayoutParams(0, dp(46), 1f))
        }
        box.addView(colors)
        box.addView(Switch(this).apply {
            text = "Nazwy aplikacji"; isChecked = showLabels
            setOnCheckedChangeListener { _, checked ->
                showLabels = checked
                prefs.edit().putBoolean("show_labels", checked).apply()
                renderApps(search.text.toString())
            }
        })
        box.addView(Switch(this).apply {
            text = "Pokaż ukryte aplikacje"; isChecked = showHiddenApps
            setOnCheckedChangeListener { _, checked ->
                showHiddenApps = checked
                prefs.edit().putBoolean("show_hidden_apps", checked).apply()
                renderApps(search.text.toString())
            }
        })
        box.addView(actionButton("ODKRYJ WSZYSTKIE APLIKACJE", 0xff293b3b.toInt()) {
            hiddenPackages.clear()
            prefs.edit().remove("hidden_packages").apply()
            renderApps(search.text.toString())
            Toast.makeText(this@MainActivity, "Przywrócono widoczność aplikacji", Toast.LENGTH_SHORT).show()
        }, lp(-1, dp(42)))
        box.addView(text("Kolumny siatki: $columns", 13f))
        box.addView(SeekBar(this).apply { max = 4; progress = columns - 2; setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { columns = p + 2; appGrid.columnCount = columns }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { prefs.edit().putInt("columns", columns).apply() }
        }) })
        box.addView(actionButton("DOSTĘP DO POWIADOMIEŃ", 0xff355d4b.toInt()) { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }, lp(-1, dp(44)))
        showDialog(box, .9f)
    }

    private fun showAppActions(packageName: String, appName: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(18)); background = glass(0xff172126.toInt(), 24f) }
        box.addView(text(appName, 18f))
        box.addView(actionButton("INFORMACJE O APLIKACJI", 0xff293b3b.toInt()) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:$packageName")))
        }, lp(-1, dp(44)))
        val isHidden = packageName in hiddenPackages
        box.addView(actionButton(if (isHidden) "POKAŻ W SZUFLADZIE" else "UKRYJ Z SZUFLADY", 0xff355d4b.toInt()) {
            if (isHidden) hiddenPackages.remove(packageName) else hiddenPackages.add(packageName)
            prefs.edit().putStringSet("hidden_packages", hiddenPackages.toSet()).apply()
            renderApps(search.text.toString())
        }, lp(-1, dp(44)))
        showDialog(box, .85f)
    }

    private fun showDialog(content: View, widthFraction: Float) {
        val dialog = Dialog(this); dialog.setContentView(content); dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.show(); dialog.window?.setLayout((resources.displayMetrics.widthPixels * widthFraction).toInt(), -2)
    }

    private fun withAlpha(color: Int, alpha: Int) = (color and 0x00ffffff) or (alpha.coerceIn(0, 255) shl 24)

}
