package com.voidx.launcher

import android.service.notification.NotificationListenerService

/** Grants VOID X access to active media sessions after the user enables notification access. */
class MediaNotificationListener : NotificationListenerService()
