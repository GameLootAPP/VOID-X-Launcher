# VOID X 1.3.0 — launcher refinement

## Implemented
- Hide individual apps from the app grid, persist the hidden package list, and optionally reveal hidden apps.
- Restore visibility for all hidden apps from settings.
- Refresh installed launcher activities when returning to the launcher.
- Remove hosted widgets with a long-press confirmation; update the persisted widget ID list.
- Unregister the active media-session callback when the activity is destroyed.
- Replace placeholder web URL dock behavior with Android's browser intent category.
- Use the platform camera capture intent for the camera dock shortcut.
- Set targetSdk 35 and increment app version metadata.

## Still not implemented
- Usage-statistics-based sorting (requires user-granted Usage Access).
- User-editable folders and drag-and-drop placement.
- System-wide overlay Dynamic Island.
- Notification mirroring, weather provider, theme export/import, icon packs and configurable gestures.
- Signed release build and physical-device validation.

This is an incremental source release. It has not been compiled or device-tested in this environment.
