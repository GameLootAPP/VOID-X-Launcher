# VOID X 1.2.0 — engineering update

- Reworked home layout into a scrollable app drawer with persistent search.
- Added dock shortcuts that resolve installed system apps rather than decorative glyph-only tiles.
- Added Android MediaSession lookup and functional transport actions to the in-launcher VOID Island.
- Added album artwork/title/artist presentation when available from the active media session.
- Added explicit notification-listener service declaration; user authorization remains required.
- Added system settings shortcuts and brightness adjustment with the Android Modify System Settings permission flow.
- Kept weather data explicitly marked as unavailable until a provider is configured.
- Updated app version to 1.2.0.
- Added AppWidgetHost picker, native widget rendering and restoration of hosted widget IDs.
- Added media-session callbacks so track metadata and playback-state changes can refresh while VOID X remains open.
