# Build VOID X 1.3.0 APK

This archive is source code; it does not contain a prebuilt APK.

## Debug APK (quick install)

1. Install Android Studio and Android SDK Platform 35.
2. Open the `VOID_X_Android_Studio` directory.
3. In Android Studio, select a compatible Gradle installation and JDK 17+; allow project sync.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. After a successful build, Android Studio shows a notification with **locate**. The debug APK is normally at:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Install on the POCO X6 Pro 5G, choose VOID X as the Home app, and test the media permission and widget picker.

## Signed release APK

1. Select **Build > Generate Signed Bundle / APK**.
2. Choose **APK** and create or select a private signing key (keep the keystore and passwords private; do not send them in chat).
3. Select the `release` build variant and finish the wizard.
4. Test the generated APK on the target device before distributing it.

## Release checklist

- Set VOID X as default Home app and reboot the phone.
- Test app discovery/search and dock launch targets.
- Enable VOID X under Android Settings > Notification access; test media metadata and transport actions with multiple media apps.
- Add and remove widgets; reboot and verify widget restoration.
- Test brightness flow both before and after granting Modify System Settings.
- Test on-device at 60 Hz and 120 Hz; measure memory, CPU and battery over a representative period.
- Confirm all permissions are user-granted and that no restricted system setting is bypassed.

A source archive or a successful IDE sync is not proof of a successful APK build. Do not label the release ready until the APK installs and these device checks pass.
