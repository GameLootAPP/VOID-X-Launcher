# VOID X 1.3.0 — native Android launcher

A Kotlin Android HOME launcher prototype for Android 8.0+ (API 26+) with a wallpaper-backed home screen, app drawer/search, configurable grid, working app shortcuts in the dock, system-settings shortcuts and an in-launcher media island backed by Android MediaSession.

## Open and build

1. Open this folder in Android Studio (JDK 17 or newer).
2. Allow Gradle to sync. The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compileSdk 35 and minSdk 26.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the debug APK and select VOID X as the default Home app.

The project does not bundle Gradle Wrapper or Android SDK. Android Studio must provide a compatible Gradle installation and SDK platform 35.

## Implemented in this iteration

- Native HOME/DEFAULT activity declaration.
- Wallpaper-backed home screen with translucent card styling.
- Installed app discovery, icon grid, alphabetical ordering, search and long-press app info shortcut.
- Dock shortcuts resolving dialer, camera, browser and Android settings.
- Persistent accent color, app-label visibility, app-grid column count, hidden-app list and show-hidden toggle.
- Expandable VOID Island reading active media sessions through MediaSessionManager after the user grants notification-listener access.
- Real play/pause, previous and next transport controls where the active media session exposes those actions; album artwork/title/artist when supplied by the app.
- Android AppWidgetHost picker, widget hosting and restoration across launcher restarts.
- Control-center-style sheet with brightness adjustment (requires the user to grant Modify System Settings) and shortcuts to Android Wi-Fi, Bluetooth, network, battery and system settings.
- Honest weather placeholder; no fake temperature or forecast.

## Known limitations — not represented as completed

- Media-session access requires the user to enable VOID X under Android Settings > Notification access. Some media apps may not expose every transport action or artwork.
- The media island is displayed inside VOID X. A system-wide floating overlay over other apps is not implemented.
- Weather API/provider is not connected.
- True notification mirroring, icon-pack loading, editable folders, theme import/export, advanced gesture configuration and animation settings are not implemented yet.
- The brightness slider requires the user to grant Modify System Settings. Wi-Fi/Bluetooth/network controls open Android settings rather than bypassing OS restrictions.
- `QUERY_ALL_PACKAGES` is used for launcher app discovery; distribution through Google Play may require policy justification.
- No APK is included in this source archive. Compilation and device testing must be completed in Android Studio on a configured Android SDK.

## Device target

Designed for a modern Android phone such as POCO X6 Pro 5G. Actual refresh-rate, memory, battery and compatibility validation must be performed on physical hardware; this source-only build cannot claim those test results.


See `CHANGELOG_1.3.0.md` for this iteration's changes and remaining limitations.
